export default function Page() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-16">
      <h1 className="text-4xl md:text-6xl font-extrabold">Vetores para CNC</h1>
      <p className="mt-3 text-neutral-300">Arquivos prontos para corte a laser & UV • SVG/DXF/PDF</p>
      <div className="mt-8">
        <a href="/catalogo" className="px-5 py-3 rounded-2xl bg-gradient-to-r from-cyan-400 to-fuchsia-500 text-neutral-950 font-bold">Ver catálogo</a>
      </div>
    </main>
  );
}