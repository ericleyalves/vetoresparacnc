import "@/styles/globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Vetores para CNC – Arquivos para corte a laser",
  description: "SVG, DXF e PDF prontos para corte a laser e impressão UV.",
  metadataBase: new URL("https://vetoresparacnc.com.br")
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-neutral-950 text-white">{children}</body>
    </html>
  );
}