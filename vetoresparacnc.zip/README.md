# Vetores para CNC

MVP inicial com Next.js + Tailwind.
